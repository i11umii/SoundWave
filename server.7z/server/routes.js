import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from './models/User.js';
import Track from './models/Track.js';
import Playlist from './models/Playlist.js';
import Artist from './models/Artist.js';
import { protect } from './middleware/auth.js';

const router = express.Router();

// --- AUTH ---
router.post('/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ message: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ username, email, password: hashedPassword });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, token, user: { id: user._id, username: user.username, email: user.email, badges: user.badges } });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(400).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, token, user: { id: user._id, username: user.username, email: user.email, badges: user.badges } });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.get('/auth/me', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password').populate('badges').populate('playlists');
    res.json({ success: true, data: user });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

// --- ARTISTS (FIXED) ---
router.get('/artists', async (req, res) => {
  try {
    const artists = await Artist.find();
    res.json({ success: true, data: artists });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.get('/artists/:id', async (req, res) => {
  try {
    // FIX: Deep populate ensures we get Track Image, Album, and Artist Name
    const artist = await Artist.findById(req.params.id)
      .populate({
        path: 'topTracks',
        populate: { path: 'artist' }
      })
      .populate('similarArtists');

    if (!artist) return res.status(404).json({ message: 'Artist not found' });

    // Get all other tracks by this artist
    const tracks = await Track.find({ artist: artist._id }).populate('artist');

    res.json({ success: true, data: { ...artist.toObject(), tracks } });
  } catch (error) {
    if (error.kind === 'ObjectId') return res.status(404).json({ message: 'Artist not found' });
    res.status(500).json({ message: error.message });
  }
});

router.post('/artists/:id/follow', protect, async (req, res) => {
  // Simplified follow logic (toggle in real app)
  res.json({ success: true });
});
router.delete('/artists/:id/follow', protect, async (req, res) => {
  res.json({ success: true });
});

// --- TRACKS ---
router.get('/tracks', async (req, res) => {
  try {
    let query = {};
    if (req.query.search) query = { title: { $regex: req.query.search, $options: 'i' } };
    const tracks = await Track.find(query).populate('artist');
    res.json({ success: true, data: tracks });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.get('/tracks/recommendations', protect, async (req, res) => {
  try {
    const tracks = await Track.find().populate('artist').limit(10);
    res.json({ success: true, data: tracks });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

// --- USER ACTIONS ---
router.get('/users/liked-tracks', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate({ path: 'likedTracks', populate: { path: 'artist' } });
    res.json({ success: true, data: user.likedTracks });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.get('/users/recently-played', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate({ path: 'recentlyPlayed.track', populate: { path: 'artist' } });
    // Sort by newest
    const history = user.recentlyPlayed.sort((a, b) => new Date(b.playedAt) - new Date(a.playedAt));
    res.json({ success: true, data: history });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.post('/users/recently-played/:id', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const track = await Track.findById(req.params.id);
    if (!track) return res.status(404).json({ message: 'Track not found' });

    user.recentlyPlayed.push({ track: track._id, playedAt: new Date() });
    track.playCount = (track.playCount || 0) + 1;
    await track.save();

    // GAMIFICATION: Early Adopter Badge
    let newBadge = null;
    if (track.playCount < 1000) {
      const hasBadge = user.badges.find(b => b.id === 'EARLY_ADOPTER');
      if (!hasBadge) {
        newBadge = { id: 'EARLY_ADOPTER', name: 'Trendsetter', icon: '💎', description: 'Discovered a hidden gem!', earnedAt: new Date() };
        user.badges.push(newBadge);
      }
    }
    await user.save();
    res.json({ success: true, newBadge });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

// --- PLAYLISTS ---
router.get('/playlists', protect, async (req, res) => {
  try {
    const playlists = await Playlist.find({ user: req.user.id });
    res.json({ success: true, data: playlists });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

router.get('/playlists/:id', protect, async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id).populate({ path: 'tracks.track', populate: { path: 'artist' } });
    if (!playlist) return res.status(404).json({ message: 'Playlist not found' });
    res.json({ success: true, data: playlist });
  } catch (error) { 
    if (error.kind === 'ObjectId') return res.status(404).json({ message: 'Playlist not found' });
    res.status(500).json({ message: error.message }); 
  }
});

router.post('/playlists', protect, async (req, res) => {
  try {
    const playlist = await Playlist.create({ ...req.body, user: req.user.id });
    await User.findByIdAndUpdate(req.user.id, { $push: { playlists: playlist._id } });
    res.json({ success: true, data: playlist });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

// --- SMART STATS & DNA ---
router.get('/smart-stats', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate({ path: 'recentlyPlayed.track', populate: { path: 'artist' } });
    const history = user.recentlyPlayed;

    // 1. Day Stats
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayCount = { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0, Sun: 0 };
    history.forEach(item => {
      const d = new Date(item.playedAt).getDay();
      dayCount[days[d]]++;
    });

    // 2. Top Artists
    const artistMap = {};
    history.forEach(item => {
      if (item.track && item.track.artist) {
        artistMap[item.track.artist.name] = (artistMap[item.track.artist.name] || 0) + 1;
      }
    });
    const topArtists = Object.entries(artistMap).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, count]) => ({ name, count }));

    // 3. Insights
    const insights = [];
    if (history.length > 5) insights.push({ type: 'artist', icon: '🎵', text: `Total plays: ${history.length}`, value: history.length });

    res.json({ success: true, data: { insights, topArtists, dayStats: Object.entries(dayCount).map(([day, count]) => ({ day, count })) } });
  } catch (error) { res.status(500).json({ message: 'Server error' }); }
});

export default router;